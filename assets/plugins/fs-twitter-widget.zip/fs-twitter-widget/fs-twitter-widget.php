<?php 
/*
Plugin Name: Foursquare Twitter Widget
Version: 1
Description: A simple widget to display Twitter feeds from the sidebar.
Author: The Foursquare Church
Author URI: http://www.foursquare.org
*/
 
class My_Twitter_Widget extends WP_Widget {
	/* Register the widget */
	function __construct() {
		parent::__construct(false, $name = 'Twitter Widget', array( 'description' => 'A shiny Twitter profile badge for your WordPress site.' ) );
	}

	/* Let's add some options */
	function form( $instance ) {
	$screen_name = esc_attr( $instance['screen_name' ] ); /* Screen name */
	$num_tweets = esc_attr( $instance['num_tweets'] ); /* Number of tweets displayed */
	?>
	<p>
		<label for="<?php echo $this->get_field_id( 'screen_name' ); ?>">Screen name:</label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'screen_name' ); ?>" name="<?php echo $this->get_field_name( 'screen_name' ); ?>" type="text" value="<?php echo $screen_name; ?>" />
	</p>
	<p>
		<label for="<?php echo $this->get_field_id( 'num_tweets' ); ?>">Number of Tweets:</label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'num_tweets' ); ?>" name="<?php echo $this->get_field_name( 'num_tweets' ); ?>" type="text" value="<?php echo $num_tweets; ?>" />
	</p>
	<?php
	}
	
	/* Output the widget */	
	function widget( $args, $instance ) {
	echo $args['before_widget'];
	?>
	<script src="http://widgets.twimg.com/j/2/widget.js"></script>
	<script>
	new TWTR.Widget({
	  version: 2,
	  type: 'profile',
	  rpp: <?php echo $instance['num_tweets']; ?>,
	  interval: 6000,
	  width: 'auto',
	  height: 300,
	  theme: {
	    shell: {
	      background: '#fff',
	      color: '#888'
	    },
	    tweets: {
	      background: '<?php echo $instance['tweet_background_color']; ?>',
	    }
	  },
	  features: {
	    scrollbar: false,
	    loop: false,
	    live: false,
	    hashtags: true,
	    timestamp: true,
	    avatars: false,
	    behavior: 'all'
	  }
	}).render().setUser('<?php echo $instance['screen_name']; ?>').start();
	</script>
	<?php
	echo $args['after_widget'];
}

};

add_action( 'widgets_init', create_function( '', 'return register_widget( "My_Twitter_Widget" );' ) );
?>